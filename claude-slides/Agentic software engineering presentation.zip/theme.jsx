// Shared design tokens + primitives for the video.
// Colors: warm paper (Anthropic-adjacent) + terracotta accent + ink.

const THEME = {
  paper:     '#f4efe6',
  paperDeep: '#ece5d7',
  paperSoft: '#faf7f0',
  ink:       '#1a1612',
  inkSoft:   '#3d352c',
  muted:     '#8a7f70',
  rule:      '#d9cfbd',
  terra:     '#c96442',
  terraDeep: '#a04a2d',
  ochre:     '#c8a464',
  sage:      '#6b7b5a',
  slate:     '#3a4a5a',
};

const FONTS = {
  display: '"Instrument Serif", "Tiempos Headline", Georgia, serif',
  body:    '"Inter", system-ui, sans-serif',
  mono:    '"JetBrains Mono", ui-monospace, SFMono-Regular, monospace',
};

// A subtle paper grain using layered radial noise (CSS only).
const PAPER_GRAIN = {
  backgroundImage: `
    radial-gradient(1200px 800px at 20% 10%, rgba(200,164,100,0.06), transparent 60%),
    radial-gradient(900px 700px at 90% 90%, rgba(201,100,66,0.04), transparent 55%)
  `,
};

// Chrome: scene label + section ticker that floats at edges of frame.
function SceneChrome({ section, index, total, showPaginate = true }) {
  return (
    <>
      {/* Top-left: section tag */}
      <div style={{
        position: 'absolute',
        top: 56, left: 80,
        fontFamily: FONTS.mono,
        fontSize: 14,
        letterSpacing: '0.14em',
        textTransform: 'uppercase',
        color: THEME.muted,
        display: 'flex', alignItems: 'center', gap: 14,
      }}>
        <span style={{
          width: 8, height: 8, borderRadius: 4,
          background: THEME.terra,
        }}/>
        Agentic Software Engineering
      </div>

      {/* Top-right: section name */}
      {section && (
        <div style={{
          position: 'absolute',
          top: 56, right: 80,
          fontFamily: FONTS.mono,
          fontSize: 13,
          letterSpacing: '0.16em',
          textTransform: 'uppercase',
          color: THEME.inkSoft,
        }}>
          {section}
        </div>
      )}

      {/* Bottom-left: page number */}
      {showPaginate && (
        <div style={{
          position: 'absolute',
          bottom: 54, left: 80,
          fontFamily: FONTS.mono,
          fontSize: 13,
          color: THEME.muted,
          letterSpacing: '0.1em',
        }}>
          {String(index).padStart(2, '0')} <span style={{opacity:0.4}}>/ {String(total).padStart(2, '0')}</span>
        </div>
      )}

      {/* Bottom-right: author */}
      <div style={{
        position: 'absolute',
        bottom: 54, right: 80,
        fontFamily: FONTS.mono,
        fontSize: 13,
        color: THEME.muted,
        letterSpacing: '0.08em',
      }}>
        Md Omar Faruqe · 2026
      </div>
    </>
  );
}

// Entry/exit helper for text blocks — returns {opacity, y}
function useFadeUp({ entryDur = 0.5, exitDur = 0.35, delay = 0, holdOnExit = false } = {}) {
  const { localTime, duration } = useSprite();
  const t = localTime - delay;
  const exitStart = Math.max(0, duration - exitDur);

  let opacity = 1;
  let y = 0;

  if (t < 0) {
    opacity = 0;
    y = 16;
  } else if (t < entryDur) {
    const p = Easing.easeOutCubic(clamp(t / entryDur, 0, 1));
    opacity = p;
    y = (1 - p) * 16;
  } else if (!holdOnExit && localTime > exitStart) {
    const p = Easing.easeInCubic(clamp((localTime - exitStart) / exitDur, 0, 1));
    opacity = 1 - p;
    y = -p * 8;
  }
  return { opacity, y, transform: `translateY(${y}px)` };
}

// Animated line that draws itself in.
function DrawLine({ x1, y1, x2, y2, delay = 0, dur = 0.5, color = THEME.ink, width = 1 }) {
  const { localTime } = useSprite();
  const t = clamp((localTime - delay) / dur, 0, 1);
  const eased = Easing.easeInOutCubic(t);
  const cx = x1 + (x2 - x1) * eased;
  const cy = y1 + (y2 - y1) * eased;
  return (
    <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
      <line x1={x1} y1={y1} x2={cx} y2={cy} stroke={color} strokeWidth={width} />
    </svg>
  );
}

// Horizontal ruled divider that wipes in.
function Rule({ x, y, width, delay = 0, color = THEME.rule, thickness = 1 }) {
  const { localTime } = useSprite();
  const p = Easing.easeOutCubic(clamp((localTime - delay) / 0.6, 0, 1));
  return (
    <div style={{
      position: 'absolute',
      left: x, top: y,
      width: width * p,
      height: thickness,
      background: color,
    }}/>
  );
}

Object.assign(window, { THEME, FONTS, PAPER_GRAIN, SceneChrome, useFadeUp, DrawLine, Rule });
