// Scenes 7-12: Prompting, Plan Mode, Primitives, Skills, MCP, Subagents+Hooks

// ─────────────────────────────────────────────────────────────
// SCENE 7 — PROMPTING: BAD vs GOOD
// ─────────────────────────────────────────────────────────────
function ScenePrompting({ start, end }) {
  return (
    <Sprite start={start} end={end}>
      <PromptingInner />
    </Sprite>
  );
}

function PromptingInner() {
  const { localTime } = useSprite();
  const q = (d) => ({
    opacity: clamp((localTime - d) / 0.5, 0, 1),
    transform: `translateY(${(1 - clamp((localTime - d) / 0.5, 0, 1)) * 12}px)`,
  });

  // Typewriter effect for the "good" prompt
  const goodText = "In LoanApplicationView.submit(), validation throws ExceptionHolder when attachments are missing. Show a field-level warning. Check BaseView.addClientErrorMessage for the pattern. Write a test first.";
  const typeStart = 2.0;
  const typeDur = 3.8;
  const charsVisible = Math.floor(clamp((localTime - typeStart) / typeDur, 0, 1) * goodText.length);
  const typed = goodText.slice(0, charsVisible);

  // Highlight spans in the good prompt
  const highlight = (text) => {
    // Emphasize file path, method, class
    return text
      .replace(/LoanApplicationView\.submit\(\)/g, '§F§$&§')
      .replace(/ExceptionHolder/g, '§F§$&§')
      .replace(/BaseView\.addClientErrorMessage/g, '§F§$&§')
      .replace(/Show a field-level warning\./g, '§C§$&§')
      .replace(/Write a test first\./g, '§C§$&§');
  };

  const renderHighlighted = (raw) => {
    const parts = highlight(raw).split('§');
    return parts.map((p, i) => {
      if (p === 'F') return null;
      if (p === 'C') return null;
      if (parts[i - 1] === 'F') return <span key={i} style={{ color: THEME.terra, fontFamily: FONTS.mono, fontSize: '0.88em' }}>{p}</span>;
      if (parts[i - 1] === 'C') return <span key={i} style={{ color: THEME.ink, fontWeight: 500 }}>{p}</span>;
      return <span key={i}>{p}</span>;
    });
  };

  return (
    <div style={{ position: 'absolute', inset: 0, background: THEME.paper, ...PAPER_GRAIN }}>
      <SceneChrome section="Prompting" index={7} total={18} />

      <div style={{
        position: 'absolute', top: 160, left: 80,
        fontFamily: FONTS.display, fontSize: 88,
        color: THEME.ink, letterSpacing: '-0.02em', lineHeight: 1,
        ...q(0.1),
      }}>
        Precise prompts → <span style={{ fontStyle: 'italic', color: THEME.terra }}>fewer corrections.</span>
      </div>

      {/* Two columns */}
      <div style={{
        position: 'absolute', top: 360, left: 80, right: 80,
        display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 60,
      }}>
        {/* BAD */}
        <div style={{ ...q(0.5) }}>
          <div style={{
            fontFamily: FONTS.mono, fontSize: 14,
            color: THEME.muted, letterSpacing: '0.14em', textTransform: 'uppercase',
            marginBottom: 18, display: 'flex', alignItems: 'center', gap: 12,
          }}>
            <span style={{ color: '#8a4a3a' }}>✕</span> BAD
          </div>
          <div style={{
            fontFamily: FONTS.display, fontSize: 56,
            color: THEME.inkSoft, lineHeight: 1.15,
            fontStyle: 'italic',
            padding: '36px 32px',
            background: THEME.paperDeep,
            borderLeft: `3px solid ${THEME.muted}`,
            position: 'relative',
          }}>
            "fix the loan approval"
          </div>
          <div style={{
            marginTop: 20,
            fontFamily: FONTS.body, fontSize: 18,
            color: THEME.muted,
          }}>
            No file. No pattern. No done criteria. Agent wastes turns reading.
          </div>
        </div>

        {/* GOOD */}
        <div style={{ ...q(1.5) }}>
          <div style={{
            fontFamily: FONTS.mono, fontSize: 14,
            color: THEME.terra, letterSpacing: '0.14em', textTransform: 'uppercase',
            marginBottom: 18, display: 'flex', alignItems: 'center', gap: 12,
          }}>
            <span>✓</span> GOOD
          </div>
          <div style={{
            fontFamily: FONTS.body, fontSize: 22,
            color: THEME.inkSoft, lineHeight: 1.55,
            padding: '36px 32px',
            background: THEME.paperSoft,
            borderLeft: `3px solid ${THEME.terra}`,
            minHeight: 260,
          }}>
            "{renderHighlighted(typed)}
            {charsVisible < goodText.length && (
              <span style={{
                display: 'inline-block', width: 10, height: 22, background: THEME.terra,
                marginLeft: 2, marginBottom: -4, opacity: Math.floor(localTime * 2.5) % 2 ? 1 : 0,
              }}/>
            )}"
          </div>
        </div>
      </div>

      {/* Formula */}
      <div style={{
        position: 'absolute', bottom: 200, left: 80, right: 80,
        ...q(6.2),
      }}>
        <div style={{
          fontFamily: FONTS.mono, fontSize: 14,
          letterSpacing: '0.14em', textTransform: 'uppercase',
          color: THEME.muted, marginBottom: 12,
        }}>
          THE FORMULA
        </div>
        <div style={{
          fontFamily: FONTS.display, fontSize: 44,
          color: THEME.ink, letterSpacing: '-0.01em',
          display: 'flex', gap: 14, alignItems: 'baseline', flexWrap: 'wrap',
        }}>
          <span>goal</span>
          <span style={{ color: THEME.terra }}>+</span>
          <span>file path</span>
          <span style={{ color: THEME.terra }}>+</span>
          <span>constraint</span>
          <span style={{ color: THEME.terra }}>+</span>
          <span>done criteria</span>
        </div>
      </div>

      {/* Proactive-context callout */}
      <div style={{
        position: 'absolute', bottom: 90, left: 80, right: 80,
        display: 'flex', alignItems: 'flex-start', gap: 18,
        paddingTop: 22,
        borderTop: `1px solid ${THEME.rule}`,
        ...q(6.8),
      }}>
        <span style={{
          fontFamily: FONTS.mono, fontSize: 13,
          letterSpacing: '0.16em', color: THEME.terra,
          marginTop: 6, flexShrink: 0,
        }}>
          ALSO
        </span>
        <div style={{
          fontFamily: FONTS.body, fontSize: 22,
          color: THEME.inkSoft, lineHeight: 1.4,
          maxWidth: 1500,
        }}>
          Provide context <span style={{ fontWeight: 600, color: THEME.ink }}>proactively</span> — or the agent wastes turns reading unnecessary files.
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SCENE 8 — PLAN MODE + STEERING
// ─────────────────────────────────────────────────────────────
function ScenePlanMode({ start, end }) {
  return (
    <Sprite start={start} end={end}>
      <PlanModeInner />
    </Sprite>
  );
}

function PlanModeInner() {
  const { localTime } = useSprite();
  const q = (d) => ({
    opacity: clamp((localTime - d) / 0.5, 0, 1),
    transform: `translateY(${(1 - clamp((localTime - d) / 0.5, 0, 1)) * 12}px)`,
  });

  // Cycling modes: default → auto-accept → plan
  const modes = ['DEFAULT', 'AUTO-ACCEPT', 'PLAN'];
  const cycleT = clamp((localTime - 1.0) / 3.0, 0, 1);
  const modeIdx = Math.min(2, Math.floor(cycleT * 3));

  return (
    <div style={{ position: 'absolute', inset: 0, background: THEME.paper, ...PAPER_GRAIN }}>
      <SceneChrome section="Plan mode + steering" index={8} total={18} />

      <div style={{
        position: 'absolute', top: 160, left: 80,
        fontFamily: FONTS.display, fontSize: 88,
        color: THEME.ink, letterSpacing: '-0.02em', lineHeight: 1,
        ...q(0.1),
      }}>
        <span style={{ fontStyle: 'italic', color: THEME.terra }}>Research</span> before edit.
      </div>

      {/* Shift+Tab cycle */}
      <div style={{
        position: 'absolute', top: 360, left: 80,
        ...q(0.5),
      }}>
        <div style={{
          fontFamily: FONTS.mono, fontSize: 13, color: THEME.muted,
          letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: 14,
        }}>
          SHIFT + TAB CYCLES
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
          {modes.map((m, i) => (
            <React.Fragment key={i}>
              <div style={{
                padding: '14px 24px',
                border: `1.5px solid ${i === modeIdx ? THEME.terra : THEME.rule}`,
                background: i === modeIdx ? THEME.paperSoft : 'transparent',
                fontFamily: FONTS.mono,
                fontSize: 16,
                color: i === modeIdx ? THEME.terra : THEME.muted,
                letterSpacing: '0.1em',
                borderRadius: 2,
                transition: 'all 200ms',
              }}>
                {m}
              </div>
              {i < modes.length - 1 && <span style={{ color: THEME.muted, fontFamily: FONTS.mono }}>→</span>}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* Plan mode benefits */}
      <div style={{
        position: 'absolute', top: 520, left: 80, right: 80,
        display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 50,
      }}>
        {[
          { tag: 'PLAN MODE', body: 'Research + propose before edit. Runs in an isolated subagent — main context stays clean.' },
          { tag: 'CAREFUL USE', body: 'Reads a lot of files. Skip for trivial edits. Let Claude use AskUserQuestion — answer honestly.' },
        ].map((it, i) => (
          <div key={i} style={{
            ...q(1.0 + i * 0.25),
            borderTop: `2px solid ${THEME.ink}`,
            paddingTop: 18,
          }}>
            <div style={{
              fontFamily: FONTS.mono, fontSize: 13,
              color: THEME.terra, letterSpacing: '0.14em',
              marginBottom: 14,
            }}>
              {it.tag}
            </div>
            <div style={{ fontFamily: FONTS.body, fontSize: 22, color: THEME.inkSoft, lineHeight: 1.45 }}>
              {it.body}
            </div>
          </div>
        ))}
      </div>

      {/* Steering commands */}
      <div style={{
        position: 'absolute', bottom: 130, left: 80, right: 80,
        ...q(2.5),
      }}>
        <div style={{
          fontFamily: FONTS.mono, fontSize: 13, color: THEME.muted,
          letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: 14,
        }}>
          STEERING
        </div>
        <div style={{
          display: 'flex', gap: 40, alignItems: 'center', flexWrap: 'wrap',
          fontFamily: FONTS.mono, fontSize: 18, color: THEME.ink,
        }}>
          <span><code style={{background: THEME.paperDeep, padding:'4px 10px', borderRadius:3}}>/clear</code> <span style={{color:THEME.muted, fontFamily: FONTS.body, fontSize: 17}}> between unrelated tasks</span></span>
          <span><code style={{background: THEME.paperDeep, padding:'4px 10px', borderRadius:3}}>/btw</code> · <code style={{background: THEME.paperDeep, padding:'4px 10px', borderRadius:3}}>--fork-session</code> <span style={{color:THEME.muted, fontFamily: FONTS.body, fontSize: 17}}> side questions</span></span>
          <span><code style={{background: THEME.paperDeep, padding:'4px 10px', borderRadius:3}}>Esc Esc</code> <span style={{color:THEME.muted, fontFamily: FONTS.body, fontSize: 17}}> rewind to checkpoint</span></span>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SCENE 9 — FIVE CONTEXT PRIMITIVES
// ─────────────────────────────────────────────────────────────
function ScenePrimitives({ start, end }) {
  return (
    <Sprite start={start} end={end}>
      <PrimitivesInner />
    </Sprite>
  );
}

function PrimitivesInner() {
  const { localTime } = useSprite();
  const q = (d) => ({
    opacity: clamp((localTime - d) / 0.5, 0, 1),
    transform: `translateY(${(1 - clamp((localTime - d) / 0.5, 0, 1)) * 12}px)`,
  });

  const rows = [
    { p: 'CLAUDE.md',  purpose: 'Always-on project context',       when: 'Conventions, base patterns, gotchas' },
    { p: 'Skills',     purpose: 'On-demand workflows',              when: 'Repeatable tasks (deploy, scaffold, review)' },
    { p: 'MCP',        purpose: 'External system connections',      when: 'DB queries, Linear, GitHub, Slack' },
    { p: 'Subagents',  purpose: 'Isolated research',                when: 'Deep exploration without polluting chat' },
    { p: 'Hooks',      purpose: 'Automation on tool events',        when: 'Auto-lint after edit, block risky commands' },
  ];

  return (
    <div style={{ position: 'absolute', inset: 0, background: THEME.paper, ...PAPER_GRAIN }}>
      <SceneChrome section="Context primitives" index={9} total={18} />

      <div style={{
        position: 'absolute', top: 160, left: 80,
        fontFamily: FONTS.display, fontSize: 88,
        color: THEME.ink, letterSpacing: '-0.02em', lineHeight: 1,
        ...q(0.1),
      }}>
        Five primitives. <span style={{ fontStyle: 'italic', color: THEME.terra }}>Compose freely.</span>
      </div>

      <div style={{
        position: 'absolute', top: 380, left: 80, right: 80,
      }}>
        {/* Header */}
        <div style={{
          display: 'grid', gridTemplateColumns: '280px 1fr 1fr',
          padding: '12px 0',
          borderBottom: `2px solid ${THEME.ink}`,
          fontFamily: FONTS.mono, fontSize: 13,
          letterSpacing: '0.14em', textTransform: 'uppercase',
          color: THEME.muted,
          ...q(0.4),
        }}>
          <div>Primitive</div>
          <div>Purpose</div>
          <div>When to use</div>
        </div>

        {rows.map((r, i) => (
          <div key={i} style={{
            display: 'grid', gridTemplateColumns: '280px 1fr 1fr',
            padding: '22px 0',
            borderBottom: `1px solid ${THEME.rule}`,
            alignItems: 'center',
            ...q(0.7 + i * 0.18),
          }}>
            <div style={{
              fontFamily: FONTS.display, fontSize: 38,
              color: THEME.ink, letterSpacing: '-0.01em',
              fontStyle: 'italic',
            }}>
              {r.p}
            </div>
            <div style={{ fontFamily: FONTS.body, fontSize: 20, color: THEME.inkSoft }}>
              {r.purpose}
            </div>
            <div style={{ fontFamily: FONTS.body, fontSize: 20, color: THEME.muted }}>
              {r.when}
            </div>
          </div>
        ))}
      </div>

      {/* Footnote */}
      <div style={{
        position: 'absolute', bottom: 130, left: 80,
        fontFamily: FONTS.body, fontSize: 22, color: THEME.inkSoft,
        fontStyle: 'italic',
        ...q(2.2),
      }}>
        <span style={{ fontFamily: FONTS.display, color: THEME.terra, fontSize: 32 }}>Plugins</span> = a bundle of these, one install.
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SCENE 10 — SKILLS
// ─────────────────────────────────────────────────────────────
function SceneSkills({ start, end }) {
  return (
    <Sprite start={start} end={end}>
      <SkillsInner />
    </Sprite>
  );
}

function SkillsInner() {
  const { localTime } = useSprite();
  const q = (d) => ({
    opacity: clamp((localTime - d) / 0.5, 0, 1),
    transform: `translateY(${(1 - clamp((localTime - d) / 0.5, 0, 1)) * 12}px)`,
  });

  return (
    <div style={{ position: 'absolute', inset: 0, background: THEME.paper, ...PAPER_GRAIN }}>
      <SceneChrome section="Skills" index={10} total={18} />

      <div style={{
        position: 'absolute', top: 160, left: 80,
        fontFamily: FONTS.display, fontSize: 88,
        color: THEME.ink, letterSpacing: '-0.02em', lineHeight: 1,
        ...q(0.1),
      }}>
        Skills. <span style={{ fontStyle: 'italic', color: THEME.terra }}>When & why.</span>
      </div>

      <div style={{
        position: 'absolute', top: 360, left: 80, right: 80,
        display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 80,
      }}>
        {/* When */}
        <div style={{ ...q(0.4) }}>
          <div style={{
            fontFamily: FONTS.mono, fontSize: 14, color: THEME.terra,
            letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: 22,
          }}>
            WHEN TO USE
          </div>
          {[
            'Recurring domain knowledge ("how to add a Jasper report").',
            'Multi-step workflows — deploy, generate Playwright from squash tests.',
            'Specialized — too narrow for CLAUDE.md.',
          ].map((t, i) => (
            <div key={i} style={{
              padding: '20px 0',
              borderBottom: `1px solid ${THEME.rule}`,
              fontFamily: FONTS.body, fontSize: 22, color: THEME.inkSoft, lineHeight: 1.4,
              display: 'flex', gap: 20,
              ...q(0.6 + i * 0.2),
            }}>
              <span style={{ fontFamily: FONTS.mono, fontSize: 14, color: THEME.muted }}>
                {String(i + 1).padStart(2, '0')}
              </span>
              <span>{t}</span>
            </div>
          ))}
        </div>

        {/* Why */}
        <div style={{ ...q(0.8) }}>
          <div style={{
            fontFamily: FONTS.mono, fontSize: 14, color: THEME.terra,
            letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: 22,
          }}>
            WHY SKILLS BEAT MCP
          </div>
          <div style={{
            fontFamily: FONTS.display, fontSize: 46,
            color: THEME.ink, letterSpacing: '-0.01em', lineHeight: 1.1,
            marginBottom: 24, fontStyle: 'italic',
          }}>
            Load only when invoked.<br/>
            <span style={{ color: THEME.terra }}>Zero idle cost.</span>
          </div>
          <div style={{
            fontFamily: FONTS.body, fontSize: 20, color: THEME.inkSoft, lineHeight: 1.5,
            paddingTop: 20, borderTop: `1px solid ${THEME.rule}`,
          }}>
            Plain markdown — easy to write, review, version in git.
          </div>
        </div>
      </div>

      {/* Invocation */}
      <div style={{
        position: 'absolute', bottom: 130, left: 80,
        fontFamily: FONTS.mono, fontSize: 18, color: THEME.ink,
        ...q(2.0),
      }}>
        <span style={{ color: THEME.muted, letterSpacing: '0.1em' }}>INVOCATION — </span>
        auto-trigger (keyword) · manual (<code style={{background: THEME.paperDeep, padding:'4px 10px', borderRadius:3, color: THEME.terra}}>/skill-name</code>)
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SCENE 11 — MCP: POWERFUL BUT SPECIFIC
// ─────────────────────────────────────────────────────────────
function SceneMCP({ start, end }) {
  return (
    <Sprite start={start} end={end}>
      <MCPInner />
    </Sprite>
  );
}

function MCPInner() {
  const { localTime } = useSprite();
  const q = (d) => ({
    opacity: clamp((localTime - d) / 0.5, 0, 1),
    transform: `translateY(${(1 - clamp((localTime - d) / 0.5, 0, 1)) * 12}px)`,
  });

  return (
    <div style={{ position: 'absolute', inset: 0, background: THEME.paper, ...PAPER_GRAIN }}>
      <SceneChrome section="MCP" index={11} total={18} />

      <div style={{
        position: 'absolute', top: 160, left: 80,
        fontFamily: FONTS.display, fontSize: 88,
        color: THEME.ink, letterSpacing: '-0.02em', lineHeight: 1,
        ...q(0.1),
      }}>
        MCP. Powerful, <span style={{ fontStyle: 'italic', color: THEME.terra }}>but specific.</span>
      </div>

      <div style={{
        position: 'absolute', top: 360, left: 80, right: 80,
      }}>
        {[
          { h: 'Lets Claude call external services', d: 'Safely. Example: DB queries via whitelisted functions (no raw SQL writes).' },
          { h: 'Names always load · schemas deferred', d: 'Tool names stay resident. Schemas now load on first use.' },
          { h: 'More servers = more upfront context',  d: 'Enable only what you need.' },
          { h: 'CLI beats MCP when available',         d: <><code style={{background: THEME.paperDeep, padding:'2px 10px', borderRadius:3, fontFamily: FONTS.mono, color: THEME.terra}}>gh</code> &nbsp; <code style={{background: THEME.paperDeep, padding:'2px 10px', borderRadius:3, fontFamily: FONTS.mono, color: THEME.terra}}>psql</code> &nbsp; <code style={{background: THEME.paperDeep, padding:'2px 10px', borderRadius:3, fontFamily: FONTS.mono, color: THEME.terra}}>aws</code></> },
        ].map((item, i) => (
          <div key={i} style={{
            display: 'grid', gridTemplateColumns: '80px 1fr',
            padding: '26px 0',
            borderBottom: `1px solid ${THEME.rule}`,
            alignItems: 'baseline',
            ...q(0.4 + i * 0.24),
          }}>
            <div style={{
              fontFamily: FONTS.mono, fontSize: 14, color: THEME.terra,
              letterSpacing: '0.14em',
            }}>
              0{i + 1}
            </div>
            <div>
              <div style={{
                fontFamily: FONTS.display, fontSize: 42,
                color: THEME.ink, letterSpacing: '-0.01em', marginBottom: 8,
              }}>
                {item.h}
              </div>
              <div style={{ fontFamily: FONTS.body, fontSize: 20, color: THEME.muted }}>
                {item.d}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SCENE 12 — SUBAGENTS + HOOKS
// ─────────────────────────────────────────────────────────────
function SceneSubagents({ start, end }) {
  return (
    <Sprite start={start} end={end}>
      <SubagentsInner />
    </Sprite>
  );
}

function SubagentsInner() {
  const { localTime } = useSprite();
  const q = (d) => ({
    opacity: clamp((localTime - d) / 0.5, 0, 1),
    transform: `translateY(${(1 - clamp((localTime - d) / 0.5, 0, 1)) * 12}px)`,
  });

  return (
    <div style={{ position: 'absolute', inset: 0, background: THEME.paper, ...PAPER_GRAIN }}>
      <SceneChrome section="Subagents + hooks" index={12} total={18} />

      <div style={{
        position: 'absolute', top: 160, left: 80,
        fontFamily: FONTS.display, fontSize: 88,
        color: THEME.ink, letterSpacing: '-0.02em', lineHeight: 1,
        ...q(0.1),
      }}>
        <span style={{ fontStyle: 'italic' }}>Branch out.</span> <span style={{ color: THEME.terra }}>React to events.</span>
      </div>

      <div style={{
        position: 'absolute', top: 380, left: 80, right: 80,
        display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 60,
      }}>
        {/* SUBAGENTS */}
        <div style={{ ...q(0.4), borderTop: `2px solid ${THEME.ink}`, paddingTop: 22 }}>
          <div style={{
            fontFamily: FONTS.mono, fontSize: 14, color: THEME.muted,
            letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: 18,
          }}>
            SUBAGENTS
          </div>
          <div style={{
            fontFamily: FONTS.display, fontSize: 42,
            color: THEME.ink, letterSpacing: '-0.01em', lineHeight: 1.1,
            marginBottom: 20, fontStyle: 'italic',
          }}>
            Isolated Claude instances.<br/>
            Own context.
          </div>
          <div style={{ fontFamily: FONTS.body, fontSize: 19, color: THEME.inkSoft, lineHeight: 1.5 }}>
            <div style={{ marginBottom: 10 }}>
              <span style={{ color: THEME.terra, fontFamily: FONTS.mono, fontSize: 15 }}>Built-in · </span>
              Explore (codebase search) · Plan (architecture) · general-purpose.
            </div>
            <div>
              <span style={{ color: THEME.terra, fontFamily: FONTS.mono, fontSize: 15 }}>Custom · </span>
              own tools, permissions, prompts. Use for deep research without polluting main chat.
            </div>
          </div>
        </div>

        {/* HOOKS */}
        <div style={{ ...q(0.8), borderTop: `2px solid ${THEME.terra}`, paddingTop: 22 }}>
          <div style={{
            fontFamily: FONTS.mono, fontSize: 14, color: THEME.terra,
            letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: 18,
          }}>
            HOOKS
          </div>
          <div style={{
            fontFamily: FONTS.display, fontSize: 42,
            color: THEME.ink, letterSpacing: '-0.01em', lineHeight: 1.1,
            marginBottom: 20, fontStyle: 'italic',
          }}>
            Shell commands on <br/>tool events.
          </div>
          <div style={{ fontFamily: FONTS.body, fontSize: 19, color: THEME.inkSoft, lineHeight: 1.5 }}>
            <div style={{ marginBottom: 10 }}>
              Auto-format on write · block <code style={{fontFamily: FONTS.mono, background: THEME.paperDeep, padding:'2px 8px', borderRadius:3, color: THEME.terra}}>rm&nbsp;-rf</code> · Slack alert on commit.
            </div>
            <div style={{ color: THEME.muted }}>
              Configured in <code style={{fontFamily: FONTS.mono, color: THEME.ink}}>settings.json</code>.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  ScenePrompting, ScenePlanMode, ScenePrimitives, SceneSkills, SceneMCP, SceneSubagents,
});
