// Scenes 13-18: Trust/Verify, Worktrees, Ecosystem, Habits (hero), Thank You

// ─────────────────────────────────────────────────────────────
// SCENE 13 — TRUST BUT VERIFY
// ─────────────────────────────────────────────────────────────
function SceneTrust({ start, end }) {
  return (
    <Sprite start={start} end={end}>
      <TrustInner />
    </Sprite>
  );
}

function TrustInner() {
  const { localTime } = useSprite();
  const q = (d) => ({
    opacity: clamp((localTime - d) / 0.5, 0, 1),
    transform: `translateY(${(1 - clamp((localTime - d) / 0.5, 0, 1)) * 12}px)`,
  });

  // ── Simpler visualization ────────────────────────────────────────────
  // One signal line traveling left → right:
  //   • Left of the "testing" gate: jittery, wavy, noisy line
  //   • Passes through a labeled gate
  //   • Right of the gate: clean, straight, steady line
  // A single packet travels the line, continuously looping.

  // Geometry
  const svgW = 1760;
  const svgH = 320;
  const yMid = svgH / 2;
  const xStart = 60;
  const xGateL = 760;
  const xGateR = 1000;
  const xEnd = 1700;

  // Build the noisy polyline on the left
  const noisyPts = [];
  const steps = 60;
  for (let i = 0; i <= steps; i++) {
    const k = i / steps;
    const x = xStart + (xGateL - xStart) * k;
    // Multiple sine waves at different frequencies + per-frame variation
    const y = yMid
      + Math.sin(localTime * 2.3 + i * 0.7) * 28
      + Math.sin(localTime * 3.7 + i * 0.21) * 16
      + Math.sin(i * 1.3) * 10;
    noisyPts.push(`${x},${y}`);
  }

  // Traveling packet position (loops)
  const cycleDur = 3.5;
  const phase = (localTime % cycleDur) / cycleDur;
  let packetX, packetY;
  if (phase < 0.45) {
    // on left noisy section
    const k = phase / 0.45;
    const idx = Math.min(steps, Math.floor(k * steps));
    const pt = noisyPts[idx].split(',');
    packetX = parseFloat(pt[0]);
    packetY = parseFloat(pt[1]);
  } else if (phase < 0.55) {
    // inside the gate — snap toward center
    const k = (phase - 0.45) / 0.10;
    const lastNoisy = noisyPts[steps].split(',');
    const startX = parseFloat(lastNoisy[0]);
    const startY = parseFloat(lastNoisy[1]);
    packetX = startX + (xGateR - startX) * k;
    packetY = startY + (yMid - startY) * k;
  } else {
    // clean straight line to end
    const k = (phase - 0.55) / 0.45;
    packetX = xGateR + (xEnd - xGateR) * k;
    packetY = yMid;
  }

  const fadeIn = (d, dur = 0.5) => clamp((localTime - d) / dur, 0, 1);
  const opLine = fadeIn(0.3);
  const opGate = fadeIn(0.6);
  const opRight = fadeIn(0.9);

  return (
    <div style={{ position: 'absolute', inset: 0, background: THEME.paper, ...PAPER_GRAIN }}>
      <SceneChrome section="Trust, but verify" index={13} total={18} />

      <div style={{
        position: 'absolute', top: 160, left: 80, right: 80,
        fontFamily: FONTS.display, fontSize: 84,
        color: THEME.ink, letterSpacing: '-0.02em', lineHeight: 1.02,
        ...q(0.1),
      }}>
        LLMs are <span style={{ fontStyle: 'italic' }}>non-deterministic.</span>
        <br/>
        Production must be <span style={{ color: THEME.terra, fontStyle: 'italic' }}>deterministic.</span>
      </div>

      {/* Side captions */}
      <div style={{
        position: 'absolute', top: 470, left: 140, width: 500,
        fontFamily: FONTS.mono, fontSize: 15, letterSpacing: '0.18em',
        color: THEME.muted, opacity: opLine,
      }}>
        LLM OUTPUT · NOISY
      </div>
      <div style={{
        position: 'absolute', top: 470, left: 1100, width: 500,
        fontFamily: FONTS.mono, fontSize: 15, letterSpacing: '0.18em',
        color: THEME.terra, opacity: opRight,
      }}>
        PRODUCTION · STEADY
      </div>

      {/* The signal diagram */}
      <svg viewBox={`0 0 ${svgW} ${svgH}`}
           style={{ position: 'absolute', top: 520, left: 80, width: svgW, height: svgH }}>
        {/* Noisy left line */}
        <polyline
          points={noisyPts.join(' ')}
          fill="none"
          stroke={THEME.muted}
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
          opacity={opLine}
        />

        {/* Testing gate */}
        <g opacity={opGate}>
          <rect
            x={xGateL} y={yMid - 110}
            width={xGateR - xGateL} height={220}
            rx="14" ry="14"
            fill={THEME.paperSoft}
            stroke={THEME.terra}
            strokeWidth="2.5"
          />
          <text
            x={(xGateL + xGateR) / 2} y={yMid - 30}
            textAnchor="middle"
            fontFamily={FONTS.display} fontSize="48"
            fontStyle="italic"
            fill={THEME.ink}>
            testing
          </text>
          <text
            x={(xGateL + xGateR) / 2} y={yMid + 10}
            textAnchor="middle"
            fontFamily={FONTS.mono} fontSize="13"
            letterSpacing="0.16em"
            fill={THEME.muted}>
            BRIDGES THE GAP
          </text>
          <text
            x={(xGateL + xGateR) / 2} y={yMid + 60}
            textAnchor="middle"
            fontFamily={FONTS.mono} fontSize="14"
            fill={THEME.terra}>
            unit · E2E · Playwright
          </text>
        </g>

        {/* Clean right line */}
        <line
          x1={xGateR} y1={yMid} x2={xEnd} y2={yMid}
          stroke={THEME.terra}
          strokeWidth="3.5"
          strokeLinecap="round"
          opacity={opRight}
        />

        {/* Traveling packet */}
        {localTime > 0.8 && (
          <g>
            <circle cx={packetX} cy={packetY} r="18" fill={THEME.terra} opacity="0.18" />
            <circle cx={packetX} cy={packetY} r="9" fill={THEME.terra} />
          </g>
        )}

        {/* End arrow/dot */}
        <g opacity={opRight}>
          <circle cx={xEnd} cy={yMid} r="8" fill={THEME.terra} />
        </g>
      </svg>

      {/* Bottom caption */}
      <div style={{
        position: 'absolute', bottom: 90, left: 80, right: 80,
        paddingTop: 18,
        borderTop: `1px solid ${THEME.rule}`,
        display: 'flex', gap: 24, alignItems: 'baseline',
        ...q(1.8),
      }}>
        <div style={{ fontFamily: FONTS.mono, fontSize: 13, color: THEME.muted, letterSpacing: '0.16em' }}>
          TESTING →
        </div>
        <div style={{ fontFamily: FONTS.display, fontSize: 28, color: THEME.ink, letterSpacing: '-0.01em' }}>
          unit · E2E · screenshots · UI flows via <span style={{ color: THEME.terra, fontStyle: 'italic' }}>Playwright</span>
          <span style={{ color: THEME.muted, fontFamily: FONTS.mono, fontSize: 15 }}> &nbsp;( /squash-e2e )</span>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SCENE 14 — WORKTREES (PARALLEL WORK)
// ─────────────────────────────────────────────────────────────
function SceneWorktrees({ start, end }) {
  return (
    <Sprite start={start} end={end}>
      <WorktreesInner />
    </Sprite>
  );
}

function WorktreesInner() {
  const { localTime } = useSprite();
  const q = (d) => ({
    opacity: clamp((localTime - d) / 0.5, 0, 1),
    transform: `translateY(${(1 - clamp((localTime - d) / 0.5, 0, 1)) * 12}px)`,
  });

  return (
    <div style={{ position: 'absolute', inset: 0, background: THEME.paper, ...PAPER_GRAIN }}>
      <SceneChrome section="Worktrees" index={14} total={18} />

      <div style={{
        position: 'absolute', top: 160, left: 80,
        fontFamily: FONTS.display, fontSize: 88,
        color: THEME.ink, letterSpacing: '-0.02em', lineHeight: 1,
        ...q(0.1),
      }}>
        Two Claudes. <span style={{ fontStyle: 'italic', color: THEME.terra }}>One repo.</span>
      </div>
      <div style={{
        position: 'absolute', top: 278, left: 80,
        fontFamily: FONTS.body, fontSize: 22, color: THEME.inkSoft, maxWidth: 1100,
        ...q(0.5),
      }}>
        Multiple sessions on the same repo = conflicts. Git worktrees give each one an isolated copy, shared history.
      </div>

      {/* Two parallel sessions diagram */}
      <div style={{
        position: 'absolute', top: 440, left: 80, right: 80,
      }}>
        <svg viewBox="0 0 1760 340" style={{ width: '100%', height: 340 }}>
          {/* Shared history rail */}
          <g opacity={clamp((localTime - 0.6) / 0.6, 0, 1)}>
            <line x1="40" y1="170" x2="1720" y2="170" stroke={THEME.rule} strokeWidth="1" strokeDasharray="4 6"/>
            <text x="40" y="200" fontFamily={FONTS.mono} fontSize="13" fill={THEME.muted} letterSpacing="0.14em">SHARED HISTORY (main)</text>
            {[200, 520, 840, 1160, 1480].map((x, i) => (
              <circle key={i} cx={x} cy="170" r="7" fill={THEME.ink} opacity={clamp((localTime - 0.8 - i * 0.1) / 0.3, 0, 1)}/>
            ))}
          </g>

          {/* Session A — top branch */}
          <g opacity={clamp((localTime - 1.4) / 0.6, 0, 1)}>
            <path d="M 520 170 Q 620 60, 1480 60" fill="none" stroke={THEME.terra} strokeWidth="2.5"/>
            <circle cx="1480" cy="60" r="10" fill={THEME.terra}/>
            <text x="1500" y="50" fontFamily={FONTS.display} fontSize="32" fill={THEME.ink} fontStyle="italic">Session A — refactor auth</text>
          </g>

          {/* Session B — bottom branch */}
          <g opacity={clamp((localTime - 1.8) / 0.6, 0, 1)}>
            <path d="M 520 170 Q 620 280, 1480 280" fill="none" stroke={THEME.slate} strokeWidth="2.5"/>
            <circle cx="1480" cy="280" r="10" fill={THEME.slate}/>
            <text x="1500" y="290" fontFamily={FONTS.display} fontSize="32" fill={THEME.ink} fontStyle="italic">Session B — write tests</text>
          </g>
        </svg>
      </div>

      {/* Bottom note */}
      <div style={{
        position: 'absolute', bottom: 140, left: 80, right: 80,
        fontFamily: FONTS.mono, fontSize: 17, color: THEME.muted,
        letterSpacing: '0.1em',
        ...q(2.6),
      }}>
        CLAUDE CODE SUPPORTS WORKTREE-ISOLATED AGENTS OUT OF THE BOX
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SCENE 15 — ECOSYSTEM TOOLS
// ─────────────────────────────────────────────────────────────
function SceneEcosystem({ start, end }) {
  return (
    <Sprite start={start} end={end}>
      <EcosystemInner />
    </Sprite>
  );
}

function EcosystemInner() {
  const { localTime } = useSprite();
  const q = (d) => ({
    opacity: clamp((localTime - d) / 0.5, 0, 1),
    transform: `translateY(${(1 - clamp((localTime - d) / 0.5, 0, 1)) * 12}px)`,
  });

  const tools = [
    { name: 'superpowers', desc: 'Curated skills / hooks / subagents' },
    { name: 'caveman',     desc: 'Prompt compression (~75% fewer tokens)' },
    { name: 'rtk',         desc: 'Smarter bash execution' },
    { name: 'claude-mem',  desc: 'Cross-session memory' },
    { name: 'graphify',    desc: 'Codebase context via graph' },
  ];

  return (
    <div style={{ position: 'absolute', inset: 0, background: THEME.paper, ...PAPER_GRAIN }}>
      <SceneChrome section="Ecosystem" index={15} total={18} />

      <div style={{
        position: 'absolute', top: 160, left: 80,
        fontFamily: FONTS.display, fontSize: 88,
        color: THEME.ink, letterSpacing: '-0.02em', lineHeight: 1,
        ...q(0.1),
      }}>
        Tools worth <span style={{ fontStyle: 'italic', color: THEME.terra }}>knowing.</span>
      </div>

      <div style={{
        position: 'absolute', top: 380, left: 80, right: 80,
      }}>
        {tools.map((t, i) => (
          <div key={i} style={{
            display: 'grid', gridTemplateColumns: '60px 380px 1fr 60px',
            alignItems: 'baseline',
            padding: '24px 0',
            borderBottom: `1px solid ${THEME.rule}`,
            ...q(0.4 + i * 0.2),
          }}>
            <div style={{ fontFamily: FONTS.mono, fontSize: 14, color: THEME.terra, letterSpacing: '0.14em' }}>
              {String(i + 1).padStart(2, '0')}
            </div>
            <div style={{
              fontFamily: FONTS.display, fontSize: 44,
              color: THEME.ink, letterSpacing: '-0.01em', fontStyle: 'italic',
            }}>
              {t.name}
            </div>
            <div style={{ fontFamily: FONTS.body, fontSize: 22, color: THEME.inkSoft }}>
              {t.desc}
            </div>
            <div style={{ fontFamily: FONTS.mono, fontSize: 14, color: THEME.muted, textAlign: 'right' }}>
              github →
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SCENE 16 — HABITS (HERO)
// ─────────────────────────────────────────────────────────────
function SceneHabits({ start, end }) {
  return (
    <Sprite start={start} end={end}>
      <HabitsInner />
    </Sprite>
  );
}

function HabitsInner() {
  const { localTime, duration } = useSprite();
  const q = (d) => ({
    opacity: clamp((localTime - d) / 0.5, 0, 1),
    transform: `translateY(${(1 - clamp((localTime - d) / 0.5, 0, 1)) * 12}px)`,
  });

  const habits = [
    {
      n: '01',
      title: "Don't whip a dead horse.",
      body: 'Wrong fix twice? Esc Esc. Rewind. Restart with a better prompt.',
    },
    {
      n: '02',
      title: 'Refactor in small, testable increments.',
      body: 'Small diffs. Green tests. Repeat.',
    },
    {
      n: '03',
      title: 'Innovate relentlessly.',
      body: 'Ask: could AI do this? Codify patterns into skills.',
    },
    {
      n: '04',
      title: 'Keep your setup fresh.',
      body: 'Prune CLAUDE.md and skills regularly.',
    },
  ];

  // Each habit appears on its own "beat"
  const beat = 1.5;
  const activeHabit = Math.min(3, Math.max(0, Math.floor((localTime - 0.4) / beat)));

  return (
    <div style={{ position: 'absolute', inset: 0, background: THEME.ink, color: THEME.paper }}>
      <SceneChrome section="Habits worth building" index={16} total={18} />

      {/* Override chrome colors for dark bg */}
      <style>{`
        /* local override not used */
      `}</style>

      <div style={{
        position: 'absolute', top: 160, left: 80,
        fontFamily: FONTS.display, fontSize: 96,
        color: THEME.paper, letterSpacing: '-0.02em', lineHeight: 1,
        ...q(0.1),
      }}>
        Four habits worth <span style={{ fontStyle: 'italic', color: THEME.terra }}>building.</span>
      </div>

      {/* Four habits, stacked, each lights up on its beat */}
      <div style={{
        position: 'absolute', top: 380, left: 80, right: 80,
      }}>
        {habits.map((h, i) => {
          const appear = clamp((localTime - (0.5 + i * beat)) / 0.6, 0, 1);
          const isActive = i === activeHabit;
          return (
            <div key={i} style={{
              display: 'grid', gridTemplateColumns: '120px 1fr',
              padding: '28px 0',
              borderBottom: `1px solid rgba(244,239,230,0.12)`,
              opacity: appear,
              transform: `translateY(${(1 - appear) * 16}px)`,
              transition: 'color 240ms',
            }}>
              <div style={{
                fontFamily: FONTS.mono, fontSize: 16,
                letterSpacing: '0.14em',
                color: isActive ? THEME.terra : 'rgba(244,239,230,0.4)',
                transition: 'color 240ms',
              }}>
                {h.n}
              </div>
              <div>
                <div style={{
                  fontFamily: FONTS.display, fontSize: 54,
                  color: isActive ? THEME.paper : 'rgba(244,239,230,0.55)',
                  letterSpacing: '-0.01em',
                  fontStyle: isActive ? 'italic' : 'normal',
                  marginBottom: 8,
                  transition: 'all 240ms',
                }}>
                  {h.title}
                </div>
                <div style={{
                  fontFamily: FONTS.body, fontSize: 20,
                  color: 'rgba(244,239,230,0.6)',
                  lineHeight: 1.5,
                  maxWidth: 1200,
                }}>
                  {h.body}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* override chrome bottom-right author color for dark */}
      <div style={{
        position: 'absolute', bottom: 54, right: 80,
        fontFamily: FONTS.mono, fontSize: 13,
        color: 'rgba(244,239,230,0.4)', letterSpacing: '0.08em',
        background: THEME.ink,
      }}>
        Md Omar Faruqe · 2026
      </div>
      <div style={{
        position: 'absolute', bottom: 54, left: 80,
        fontFamily: FONTS.mono, fontSize: 13,
        color: 'rgba(244,239,230,0.4)', letterSpacing: '0.1em',
        background: THEME.ink,
      }}>
        16 <span style={{opacity:0.5}}>/ 18</span>
      </div>
      <div style={{
        position: 'absolute', top: 56, right: 80,
        fontFamily: FONTS.mono, fontSize: 13,
        color: 'rgba(244,239,230,0.7)',
        letterSpacing: '0.16em', textTransform: 'uppercase',
        background: THEME.ink,
      }}>
        Habits worth building
      </div>
      <div style={{
        position: 'absolute', top: 56, left: 80,
        fontFamily: FONTS.mono, fontSize: 14, letterSpacing: '0.14em',
        textTransform: 'uppercase',
        color: 'rgba(244,239,230,0.5)',
        display: 'flex', alignItems: 'center', gap: 14,
        background: THEME.ink,
      }}>
        <span style={{ width: 8, height: 8, borderRadius: 4, background: THEME.terra }}/>
        Agentic Software Engineering
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SCENE 17 — SUMMARY (single takeaway)
// ─────────────────────────────────────────────────────────────
function SceneSummary({ start, end }) {
  return (
    <Sprite start={start} end={end}>
      <SummaryInner />
    </Sprite>
  );
}

function SummaryInner() {
  const { localTime, duration } = useSprite();
  const q = (d) => ({
    opacity: clamp((localTime - d) / 0.5, 0, 1),
    transform: `translateY(${(1 - clamp((localTime - d) / 0.5, 0, 1)) * 12}px)`,
  });

  const lines = [
    'A loop.',
    'A few tools.',
    'A little context.',
    'A lot of review.',
  ];

  return (
    <div style={{ position: 'absolute', inset: 0, background: THEME.paper, ...PAPER_GRAIN }}>
      <SceneChrome section="The whole thing" index={17} total={18} />

      <div style={{
        position: 'absolute', top: 200, left: 80,
        fontFamily: FONTS.mono, fontSize: 15,
        color: THEME.terra, letterSpacing: '0.2em', textTransform: 'uppercase',
        ...q(0.1),
      }}>
        If you remember nothing else —
      </div>

      <div style={{
        position: 'absolute', top: 280, left: 80, right: 80,
        fontFamily: FONTS.display, fontSize: 200, lineHeight: 1,
        color: THEME.ink, letterSpacing: '-0.03em',
      }}>
        {lines.map((line, i) => {
          const delay = 0.5 + i * 0.5;
          const t = clamp((localTime - delay) / 0.8, 0, 1);
          const eased = Easing.easeOutCubic(t);
          return (
            <div key={i} style={{
              opacity: eased,
              transform: `translateY(${(1 - eased) * 30}px)`,
              fontStyle: i === 3 ? 'italic' : 'normal',
              color: i === 3 ? THEME.terra : THEME.ink,
              marginBottom: i === 3 ? 0 : -6,
            }}>
              {line}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SCENE 18 — THANK YOU
// ─────────────────────────────────────────────────────────────
function SceneThanks({ start, end }) {
  return (
    <Sprite start={start} end={end}>
      <ThanksInner />
    </Sprite>
  );
}

function ThanksInner() {
  const { localTime, duration } = useSprite();

  const titleQ = useFadeUp({ delay: 0.2, entryDur: 0.8 });
  const metaQ  = useFadeUp({ delay: 1.2, entryDur: 0.6 });

  // Gently rotating orbit mark
  const t = localTime;
  const angle = t * 0.8;
  const R = 40;

  return (
    <div style={{ position: 'absolute', inset: 0, background: THEME.paper, ...PAPER_GRAIN }}>
      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center',
      }}>
        {/* Orbit mark */}
        <div style={{ marginBottom: 40, opacity: clamp((localTime - 0.1) / 0.6, 0, 1) }}>
          <svg width="140" height="140" viewBox="-70 -70 140 140">
            <circle cx="0" cy="0" r={R} fill="none" stroke={THEME.rule} strokeWidth="1" strokeDasharray="2 4"/>
            <circle cx={Math.cos(angle) * R} cy={Math.sin(angle) * R} r="6" fill={THEME.terra}/>
            <circle cx={Math.cos(angle + Math.PI) * R} cy={Math.sin(angle + Math.PI) * R} r="3" fill={THEME.ink}/>
            <circle cx="0" cy="0" r="3" fill={THEME.ink}/>
          </svg>
        </div>

        <div style={{
          fontFamily: FONTS.display, fontSize: 220,
          color: THEME.ink, letterSpacing: '-0.03em', lineHeight: 1,
          ...titleQ,
        }}>
          Thank <span style={{ color: THEME.terra, fontStyle: 'italic' }}>you.</span>
        </div>

        <div style={{
          marginTop: 48,
          fontFamily: FONTS.mono, fontSize: 16,
          color: THEME.muted, letterSpacing: '0.18em', textTransform: 'uppercase',
          ...metaQ,
        }}>
          Md Omar Faruqe &nbsp;·&nbsp; April 21, 2026
        </div>

        <div style={{
          marginTop: 14,
          fontFamily: FONTS.body, fontSize: 20, fontStyle: 'italic',
          color: THEME.inkSoft,
          ...metaQ,
        }}>
          Questions welcome.
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  SceneTrust, SceneWorktrees, SceneEcosystem, SceneHabits, SceneSummary, SceneThanks,
});
