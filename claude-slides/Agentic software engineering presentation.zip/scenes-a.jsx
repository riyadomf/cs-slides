// Scenes 1-6: Title, Agent, Loop, Tools, Tool table, Context

// ─────────────────────────────────────────────────────────────
// SCENE 1 — TITLE
// ─────────────────────────────────────────────────────────────
function SceneTitle({ start, end }) {
  return (
    <Sprite start={start} end={end}>
      <TitleInner />
    </Sprite>
  );
}

function TitleInner() {
  const { localTime, duration } = useSprite();
  const exitStart = duration - 0.6;

  // Subtle parallax drift
  const drift = Math.sin(localTime * 0.4) * 4;

  // Pre-title label
  const labelFade = useFadeUp({ delay: 0.1, entryDur: 0.5 });

  // Main title — reveal word-by-word
  const title = ['Agentic', 'Software', 'Engineering'];

  // Subtitle (date + author)
  const metaFade = useFadeUp({ delay: 1.9, entryDur: 0.6 });

  // Animated dot that draws a small orbit around a "+" in corner
  const t = localTime;
  const orbitAngle = t * 0.9;
  const orbitR = 28;

  // Global exit
  let globalOp = 1;
  if (localTime > exitStart) {
    globalOp = 1 - clamp((localTime - exitStart) / 0.6, 0, 1);
  }

  return (
    <div style={{
      position: 'absolute', inset: 0,
      background: THEME.paper,
      ...PAPER_GRAIN,
      opacity: globalOp,
    }}>
      {/* Label */}
      <div style={{
        position: 'absolute',
        top: 180, left: 120,
        fontFamily: FONTS.mono,
        fontSize: 15,
        letterSpacing: '0.2em',
        textTransform: 'uppercase',
        color: THEME.terra,
        display: 'flex', alignItems: 'center', gap: 14,
        ...labelFade,
      }}>
        <span style={{
          width: 28, height: 1, background: THEME.terra, display: 'inline-block',
        }}/>
        Internal Engineering · Talk
      </div>

      {/* Title */}
      <div style={{
        position: 'absolute',
        top: 240, left: 120,
        fontFamily: FONTS.display,
        fontSize: 188,
        lineHeight: 0.98,
        color: THEME.ink,
        letterSpacing: '-0.03em',
        fontWeight: 400,
        maxWidth: 1700,
      }}>
        {title.map((word, i) => {
          const wordDelay = 0.35 + i * 0.18;
          const t = clamp((localTime - wordDelay) / 0.7, 0, 1);
          const eased = Easing.easeOutCubic(t);
          return (
            <div key={i} style={{
              display: 'block',
              transform: `translateY(${(1 - eased) * 40}px)`,
              opacity: eased,
              fontStyle: i === 1 ? 'italic' : 'normal',
              color: i === 1 ? THEME.terra : THEME.ink,
            }}>
              {word}
            </div>
          );
        })}
      </div>

      {/* Meta */}
      <div style={{
        position: 'absolute',
        bottom: 180, left: 120, right: 120,
        display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end',
        ...metaFade,
      }}>
        <div>
          <div style={{
            fontFamily: FONTS.mono,
            fontSize: 14,
            color: THEME.muted,
            letterSpacing: '0.1em',
            marginBottom: 8,
          }}>
            PRESENTED BY
          </div>
          <div style={{
            fontFamily: FONTS.display,
            fontSize: 44,
            color: THEME.ink,
            letterSpacing: '-0.01em',
          }}>
            Md Omar Faruqe
          </div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{
            fontFamily: FONTS.mono,
            fontSize: 14,
            color: THEME.muted,
            letterSpacing: '0.1em',
            marginBottom: 8,
          }}>
            DATE
          </div>
          <div style={{
            fontFamily: FONTS.display,
            fontSize: 44,
            color: THEME.ink,
            letterSpacing: '-0.01em',
          }}>
            April 21, 2026
          </div>
        </div>
      </div>

      {/* Orbit mark — top right */}
      <div style={{
        position: 'absolute', top: 220, right: 180,
        width: 120, height: 120,
        opacity: clamp((localTime - 0.5) / 0.8, 0, 1),
      }}>
        <svg width="120" height="120" viewBox="-60 -60 120 120">
          <circle cx="0" cy="0" r={orbitR} fill="none" stroke={THEME.rule} strokeWidth="1" strokeDasharray="2 3"/>
          <circle cx={Math.cos(orbitAngle) * orbitR} cy={Math.sin(orbitAngle) * orbitR} r="5" fill={THEME.terra}/>
          <circle cx="0" cy="0" r="3" fill={THEME.ink}/>
          <text x="0" y="50" textAnchor="middle" fontFamily={FONTS.mono} fontSize="11" fill={THEME.muted} letterSpacing="0.2em">AGENT · LOOP</text>
        </svg>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SCENE 2 — WHAT IS AN AGENT
// Equation reveal: Agent = Model + Tools + Harness
// ─────────────────────────────────────────────────────────────
function SceneAgent({ start, end }) {
  return (
    <Sprite start={start} end={end}>
      <AgentInner />
    </Sprite>
  );
}

function AgentInner() {
  const { localTime } = useSprite();

  const q = (d) => ({
    opacity: clamp((localTime - d) / 0.5, 0, 1),
    transform: `translateY(${(1 - clamp((localTime - d) / 0.5, 0, 1)) * 16}px)`,
  });

  const Item = ({ label, desc, delay, color }) => (
    <div style={{ ...q(delay) }}>
      <div style={{
        fontFamily: FONTS.display, fontSize: 112, color,
        lineHeight: 1, letterSpacing: '-0.02em',
      }}>
        {label}
      </div>
      <div style={{
        fontFamily: FONTS.body, fontSize: 20, color: THEME.inkSoft,
        marginTop: 14, maxWidth: 340, lineHeight: 1.4,
      }}>
        {desc}
      </div>
    </div>
  );

  return (
    <div style={{ position: 'absolute', inset: 0, background: THEME.paper, ...PAPER_GRAIN }}>
      <SceneChrome section="What is an agent?" index={2} total={18} />

      {/* Heading */}
      <div style={{
        position: 'absolute', top: 150, left: 80, right: 80,
        fontFamily: FONTS.display, fontSize: 76,
        color: THEME.ink, letterSpacing: '-0.02em', lineHeight: 1.05,
        ...q(0.1),
      }}>
        An agent is a <span style={{ fontStyle: 'italic', color: THEME.terra }}>recipe</span> with three ingredients.
      </div>

      {/* Equation row */}
      <div style={{
        position: 'absolute',
        top: 560, left: 80, right: 80,
        display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between',
      }}>
        <Item label="Model" desc="Reasons. In our world, Claude." delay={0.9} color={THEME.ink} />
        <div style={{
          fontFamily: FONTS.display, fontSize: 112, color: THEME.muted,
          ...q(1.15), marginTop: 0,
        }}>+</div>
        <Item label="Tools" desc="Acts — reads files, runs commands, searches the web." delay={1.3} color={THEME.ink} />
        <div style={{
          fontFamily: FONTS.display, fontSize: 112, color: THEME.muted,
          ...q(1.55),
        }}>+</div>
        <Item label="Harness" desc="The glue. Context, memory, tool access. Claude Code." delay={1.7} color={THEME.terra} />
      </div>

      {/* Bottom summary */}
      <div style={{
        position: 'absolute',
        bottom: 140, left: 80, right: 80,
        ...q(2.4),
      }}>
        <div style={{
          fontFamily: FONTS.mono, fontSize: 16, color: THEME.muted,
          letterSpacing: '0.12em', textTransform: 'uppercase',
          display: 'flex', alignItems: 'center', gap: 18,
        }}>
          <span style={{ width: 28, height: 1, background: THEME.rule }}/>
          model <span style={{color: THEME.terra}}>+</span> tools <span style={{color: THEME.terra}}>+</span> harness <span style={{color: THEME.terra}}>=</span> an agent
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SCENE 3 — THE AGENT LOOP (HERO)
// ─────────────────────────────────────────────────────────────
function SceneLoop({ start, end }) {
  return (
    <Sprite start={start} end={end}>
      <LoopInner />
    </Sprite>
  );
}

function LoopInner() {
  const { localTime, duration } = useSprite();
  const q = (d) => ({
    opacity: clamp((localTime - d) / 0.5, 0, 1),
    transform: `translateY(${(1 - clamp((localTime - d) / 0.5, 0, 1)) * 12}px)`,
  });

  // Horizontal flow diagram that matches the reference image:
  //   [Your prompt] → [Gather context] → [Take action] → [Verify results] → [Done]
  // with a dashed "agentic loop" box around the three middle nodes, a green
  // feedback arrow from Verify back to Gather, and an orange "You: interrupt,
  // steer, or add context" tag dashed-connecting up into the loop.

  // Per-loop cycle duration: the signal travels prompt→done while the
  // agentic loop internally beats. We run two-phase: (1) build up (0–2.5s),
  // (2) continuous loop from 2.5s on.
  const buildEnd = 2.5;
  const loopT = Math.max(0, localTime - buildEnd);

  // "Active node" pulses around the three middle nodes
  const cycleDur = 3.2;
  const phase = (loopT % cycleDur) / cycleDur;         // 0..1
  const activeMid = Math.floor(phase * 3);             // 0, 1, 2 → Gather, Act, Verify

  // Layout (1920×1080)
  const nodes = [
    { id: 'prompt',  x: 160,  y: 560, w: 240, h: 110, label: 'Your prompt',    kind: 'neutral' },
    { id: 'gather',  x: 500,  y: 560, w: 280, h: 110, label: 'Gather context', kind: 'loop'    },
    { id: 'act',     x: 850,  y: 560, w: 260, h: 110, label: 'Take action',    kind: 'loop'    },
    { id: 'verify',  x: 1180, y: 560, w: 280, h: 110, label: 'Verify results', kind: 'loop'    },
    { id: 'done',    x: 1540, y: 560, w: 180, h: 110, label: 'Done',           kind: 'neutral' },
  ];

  // Loop bounding box (around gather/act/verify)
  const loopBoxX = 460,  loopBoxY = 430;
  const loopBoxW = 1040, loopBoxH = 340;

  // You-tag box
  const youX = 120, youY = 850, youW = 360, youH = 140;

  // Helper to center a node
  const center = (n) => ({ cx: n.x + n.w / 2, cy: n.y + n.h / 2 });

  // Signal dot animation — rides the main path: prompt→gather→act→verify→done
  // looping continuously. Six legs: p→g (0..1), g→a (1..2), a→v (2..3),
  // v→g feedback curve (3..4 for the first time), then repeat a→v→g, and
  // occasionally exit to done. We simplify: loop g→a→v→g on repeat, with an
  // "escape to done" flash that coincides with the full cycle completing.
  // For visual simplicity, keep three signal dots: one on each top arrow.

  const gatherC = center(nodes[1]);
  const actC    = center(nodes[2]);
  const verifyC = center(nodes[3]);

  // Feedback arc control point (below Verify, curves down to Gather)
  const fbStart = { x: verifyC.cx - 40, y: nodes[3].y + nodes[3].h };
  const fbEnd   = { x: gatherC.cx - 40, y: nodes[1].y + nodes[1].h };
  const fbCtrl  = { x: (fbStart.x + fbEnd.x) / 2, y: 850 };

  // Build-in opacities
  const fadeIn = (delay, dur = 0.45) => clamp((localTime - delay) / dur, 0, 1);
  const opPrompt  = fadeIn(0.2);
  const opArrow1  = fadeIn(0.45);
  const opGather  = fadeIn(0.7);
  const opArrow2  = fadeIn(0.95);
  const opAct     = fadeIn(1.2);
  const opArrow3  = fadeIn(1.45);
  const opVerify  = fadeIn(1.7);
  const opArrow4  = fadeIn(1.95);
  const opDone    = fadeIn(2.2);
  const opLoopBox = fadeIn(2.4);
  const opFeedback= fadeIn(2.6);
  const opYou     = fadeIn(2.9);

  // Animated feedback dot traveling the green loop
  const showDot = localTime > buildEnd;
  const dotT = phase;
  // dot travels: gather(0)→act(0.33)→verify(0.66)→back to gather via arc(1)
  let dotX = 0, dotY = 0;
  if (dotT < 0.28) {
    const k = dotT / 0.28;
    dotX = gatherC.cx + (actC.cx - gatherC.cx) * k;
    dotY = gatherC.cy;
  } else if (dotT < 0.56) {
    const k = (dotT - 0.28) / 0.28;
    dotX = actC.cx + (verifyC.cx - actC.cx) * k;
    dotY = actC.cy;
  } else {
    // Travel the feedback curve from verify bottom back to gather bottom
    const k = (dotT - 0.56) / 0.44;
    // Quadratic Bezier
    const t = k;
    const omt = 1 - t;
    dotX = omt * omt * fbStart.x + 2 * omt * t * fbCtrl.x + t * t * fbEnd.x;
    dotY = omt * omt * fbStart.y + 2 * omt * t * fbCtrl.y + t * t * fbEnd.y;
  }

  return (
    <div style={{ position: 'absolute', inset: 0, background: THEME.paper, ...PAPER_GRAIN }}>
      <SceneChrome section="The Agent Loop" index={3} total={18} />

      {/* Heading */}
      <div style={{
        position: 'absolute', top: 150, left: 80, right: 80,
        fontFamily: FONTS.display, fontSize: 88,
        color: THEME.ink, letterSpacing: '-0.02em', lineHeight: 1.0,
        ...q(0.1),
      }}>
        The <span style={{ fontStyle: 'italic', color: THEME.terra }}>agentic loop.</span>
      </div>
      <div style={{
        position: 'absolute', top: 268, left: 80, right: 80,
        fontFamily: FONTS.body, fontSize: 22, color: THEME.inkSoft,
        ...q(0.4),
      }}>
        Gather context → Take action → Verify results — until the goal is met. You can interrupt, steer, or add context.
      </div>

      {/* SVG with arrows, boxes, loop, feedback curve, traveling dot */}
      <svg style={{ position: 'absolute', inset: 0 }} viewBox="0 0 1920 1080">
        <defs>
          <marker id="arrow-ink" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="8" markerHeight="8" orient="auto">
            <path d="M0,0 L10,5 L0,10 Z" fill={THEME.inkSoft} />
          </marker>
          <marker id="arrow-sage" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="8" markerHeight="8" orient="auto">
            <path d="M0,0 L10,5 L0,10 Z" fill={THEME.sage} />
          </marker>
          <marker id="arrow-terra" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="8" markerHeight="8" orient="auto">
            <path d="M0,0 L10,5 L0,10 Z" fill={THEME.terra} />
          </marker>
        </defs>

        {/* Dashed loop bounding box */}
        <g opacity={opLoopBox}>
          <rect x={loopBoxX} y={loopBoxY} width={loopBoxW} height={loopBoxH}
                rx="18" ry="18"
                fill="none"
                stroke={THEME.sage}
                strokeWidth="2"
                strokeDasharray="8 8"
                opacity="0.55"
          />
          <text x={loopBoxX + loopBoxW / 2} y={loopBoxY + 34}
                textAnchor="middle"
                fontFamily={FONTS.mono}
                fontSize="18"
                letterSpacing="0.16em"
                fill={THEME.sage}
                opacity="0.8">
            AGENTIC LOOP
          </text>
        </g>

        {/* Straight arrows between the five nodes */}
        {/* prompt → gather */}
        <line x1={nodes[0].x + nodes[0].w} y1={center(nodes[0]).cy}
              x2={nodes[1].x - 6}           y2={center(nodes[1]).cy}
              stroke={THEME.inkSoft} strokeWidth="2.5"
              markerEnd="url(#arrow-ink)"
              opacity={opArrow1} />
        {/* gather → act */}
        <line x1={nodes[1].x + nodes[1].w} y1={center(nodes[1]).cy}
              x2={nodes[2].x - 6}           y2={center(nodes[2]).cy}
              stroke={THEME.inkSoft} strokeWidth="2.5"
              markerEnd="url(#arrow-ink)"
              opacity={opArrow2} />
        {/* act → verify */}
        <line x1={nodes[2].x + nodes[2].w} y1={center(nodes[2]).cy}
              x2={nodes[3].x - 6}           y2={center(nodes[3]).cy}
              stroke={THEME.inkSoft} strokeWidth="2.5"
              markerEnd="url(#arrow-ink)"
              opacity={opArrow3} />
        {/* verify → done */}
        <line x1={nodes[3].x + nodes[3].w} y1={center(nodes[3]).cy}
              x2={nodes[4].x - 6}           y2={center(nodes[4]).cy}
              stroke={THEME.inkSoft} strokeWidth="2.5"
              markerEnd="url(#arrow-ink)"
              opacity={opArrow4} />

        {/* Green feedback arc: verify → gather (below) */}
        <g opacity={opFeedback}>
          <path
            d={`M ${fbStart.x} ${fbStart.y} Q ${fbCtrl.x} ${fbCtrl.y} ${fbEnd.x} ${fbEnd.y}`}
            fill="none"
            stroke={THEME.sage}
            strokeWidth="3"
            markerEnd="url(#arrow-sage)"
          />
        </g>

        {/* Nodes */}
        {nodes.map((n, i) => {
          const op = [opPrompt, opGather, opAct, opVerify, opDone][i];
          const isLoop = n.kind === 'loop';
          const isActive = isLoop && showDot && (['gather','act','verify'][activeMid] === n.id);
          return (
            <g key={n.id} opacity={op}>
              <rect
                x={n.x} y={n.y} width={n.w} height={n.h}
                rx="10" ry="10"
                fill={isLoop ? (isActive ? '#cfe0c1' : '#dbe7cf') : THEME.paperDeep}
                stroke={isActive ? THEME.sage : 'none'}
                strokeWidth={isActive ? 2.5 : 0}
                style={{ transition: 'fill 200ms, stroke 200ms' }}
              />
              <text
                x={n.x + n.w / 2} y={n.y + n.h / 2 + 10}
                textAnchor="middle"
                fontFamily={FONTS.body}
                fontSize="26"
                fontWeight={isLoop ? 600 : 500}
                fill={THEME.ink}
              >
                {n.label}
              </text>
            </g>
          );
        })}

        {/* You-tag box with dashed connector */}
        <g opacity={opYou}>
          <rect
            x={youX} y={youY} width={youW} height={youH}
            rx="10" ry="10"
            fill="#fbf1ea"
            stroke={THEME.terra}
            strokeWidth="1.8"
          />
          <text
            x={youX + youW / 2} y={youY + youH / 2 - 8}
            textAnchor="middle"
            fontFamily={FONTS.body}
            fontSize="22"
            fill={THEME.ink}
          >
            You: interrupt, steer,
          </text>
          <text
            x={youX + youW / 2} y={youY + youH / 2 + 24}
            textAnchor="middle"
            fontFamily={FONTS.body}
            fontSize="22"
            fill={THEME.ink}
          >
            or add context
          </text>
          {/* Dashed terracotta line from top-right of you-box up into the loop body */}
          <path
            d={`M ${youX + youW} ${youY + youH / 2} L ${fbCtrl.x - 60} ${fbCtrl.y - 10}`}
            stroke={THEME.terra}
            strokeWidth="2"
            strokeDasharray="7 7"
            fill="none"
            markerEnd="url(#arrow-terra)"
          />
        </g>

        {/* Traveling signal dot (inside loop) */}
        {showDot && (
          <g>
            <circle cx={dotX} cy={dotY} r="9" fill={THEME.sage} />
            <circle cx={dotX} cy={dotY} r="18" fill={THEME.sage} opacity="0.18" />
          </g>
        )}
      </svg>

      {/* Caption */}
      <div style={{
        position: 'absolute', bottom: 80, right: 80,
        fontFamily: FONTS.display, fontSize: 34, color: THEME.ink,
        letterSpacing: '-0.01em', maxWidth: 640, fontStyle: 'italic',
        textAlign: 'right',
        ...q(3.0),
      }}>
        Review is <span style={{ color: THEME.terra, fontWeight: 500, fontStyle:'normal' }}>non-negotiable.</span>
      </div>
    </div>
  );
}

// SVG arc helper (for the traveling path)
function describeArc(cx, cy, r, startDeg, endDeg) {
  const toXY = (d) => {
    const rad = (d * Math.PI) / 180;
    return [cx + Math.cos(rad) * r, cy + Math.sin(rad) * r];
  };
  const [sx, sy] = toXY(startDeg);
  const [ex, ey] = toXY(endDeg);
  const large = Math.abs(endDeg - startDeg) > 180 ? 1 : 0;
  const sweep = endDeg > startDeg ? 1 : 0;
  return `M ${sx} ${sy} A ${r} ${r} 0 ${large} ${sweep} ${ex} ${ey}`;
}

// ─────────────────────────────────────────────────────────────
// SCENE 4 — HOW TOOLS WORK
// ─────────────────────────────────────────────────────────────
function SceneTools({ start, end }) {
  return (
    <Sprite start={start} end={end}>
      <ToolsInner />
    </Sprite>
  );
}

function ToolsInner() {
  const { localTime } = useSprite();
  const q = (d) => ({
    opacity: clamp((localTime - d) / 0.5, 0, 1),
    transform: `translateY(${(1 - clamp((localTime - d) / 0.5, 0, 1)) * 12}px)`,
  });

  // Reference diagram:
  //   In →  [LLM call 🧠]  — action →  [Tool 🔧]  → Out
  //                   ↖________ feedback ________↙
  //
  // Boxes have dashed borders; nodes are icon-centric; feedback arc curves
  // below. The scene runs in a continuous loop — as soon as a packet of
  // "signal" reaches Out, a new one enters at In.

  // Layout (1920×1080) — centered vertically around y=540
  const boxY = 430;
  const boxH = 240;
  const llmX = 560,  llmW = 300;    // LLM call box
  const toolX = 1120, toolW = 300;  // Tool box
  const inX = 180;   const inY = 540;
  const outX = 1680; const outY = 540;

  const llmCx = llmX + llmW / 2;
  const llmCy = boxY + boxH / 2;
  const toolCx = toolX + toolW / 2;
  const toolCy = boxY + boxH / 2;

  // Arrow segments:
  //   seg0: In → LLM (left side of LLM box)
  //   seg1: LLM → Tool  ("action")
  //   seg2: Tool → Out
  //   seg3: Tool → LLM (feedback arc, below)
  // Loop cycle duration per packet
  const cycleDur = 4.0;
  const buildEnd = 1.8;           // build-in time
  const loopT = Math.max(0, localTime - buildEnd);
  const phase = (loopT % cycleDur) / cycleDur;  // 0..1

  // Split phase across segments:
  //   0.00–0.20: In → LLM
  //   0.20–0.45: LLM → Tool
  //   0.45–0.65: Tool → LLM (feedback arc)
  //   0.65–0.85: LLM → Tool (second pass, symbolic)
  //   0.85–1.00: Tool → Out
  // Signal dot position
  const segments = [
    { from: [inX + 60, inY], to: [llmX, llmCy], t0: 0.00, t1: 0.20, kind: 'line' },
    { from: [llmX + llmW, llmCy], to: [toolX, toolCy], t0: 0.20, t1: 0.45, kind: 'line' },
    { from: [toolX + 60, boxY + boxH], to: [llmX + llmW - 60, boxY + boxH], t0: 0.45, t1: 0.65, kind: 'arc',
      ctrl: [(llmCx + toolCx) / 2, 920] },
    { from: [llmX + llmW, llmCy], to: [toolX, toolCy], t0: 0.65, t1: 0.85, kind: 'line' },
    { from: [toolX + toolW, toolCy], to: [outX - 60, outY], t0: 0.85, t1: 1.00, kind: 'line' },
  ];

  let dotX = 0, dotY = 0, dotOp = 0;
  if (localTime > buildEnd) {
    dotOp = 1;
    for (const seg of segments) {
      if (phase >= seg.t0 && phase <= seg.t1) {
        const k = (phase - seg.t0) / (seg.t1 - seg.t0);
        if (seg.kind === 'line') {
          dotX = seg.from[0] + (seg.to[0] - seg.from[0]) * k;
          dotY = seg.from[1] + (seg.to[1] - seg.from[1]) * k;
        } else {
          // quadratic bezier
          const omt = 1 - k;
          dotX = omt * omt * seg.from[0] + 2 * omt * k * seg.ctrl[0] + k * k * seg.to[0];
          dotY = omt * omt * seg.from[1] + 2 * omt * k * seg.ctrl[1] + k * k * seg.to[1];
        }
        break;
      }
    }
  }

  // Which station is "active"
  const llmActive  = phase < 0.20 || (phase > 0.45 && phase < 0.65);
  const toolActive = (phase > 0.20 && phase < 0.45) || (phase > 0.65 && phase < 0.85);

  // Build-in fades
  const fadeIn = (delay, dur = 0.45) => clamp((localTime - delay) / dur, 0, 1);
  const opIn      = fadeIn(0.2);
  const opArrow1  = fadeIn(0.45);
  const opLLM     = fadeIn(0.65);
  const opArrow2  = fadeIn(0.9);
  const opAction  = fadeIn(1.0);
  const opTool    = fadeIn(1.15);
  const opArrow3  = fadeIn(1.35);
  const opOut     = fadeIn(1.5);
  const opFeedback= fadeIn(1.7);

  return (
    <div style={{ position: 'absolute', inset: 0, background: THEME.paper, ...PAPER_GRAIN }}>
      <SceneChrome section="How tools work" index={4} total={18} />

      {/* Heading */}
      <div style={{
        position: 'absolute', top: 150, left: 80,
        fontFamily: FONTS.display, fontSize: 88,
        color: THEME.ink, letterSpacing: '-0.02em', lineHeight: 1,
        ...q(0.1),
      }}>
        Tools make Claude <span style={{ fontStyle: 'italic', color: THEME.terra }}>agentic.</span>
      </div>
      <div style={{
        position: 'absolute', top: 268, left: 80, right: 80,
        fontFamily: FONTS.body, fontSize: 22, color: THEME.inkSoft, maxWidth: 1300,
        ...q(0.4),
      }}>
        Each tool result feeds back into the loop. The model decides, calls a tool, observes the result, and decides again — until the goal is met.
      </div>

      {/* Diagram */}
      <svg style={{ position: 'absolute', inset: 0 }} viewBox="0 0 1920 1080">
        <defs>
          <marker id="arr-ink2" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="8" markerHeight="8" orient="auto">
            <path d="M0,0 L10,5 L0,10 Z" fill={THEME.ink} />
          </marker>
        </defs>

        {/* In label */}
        <g opacity={opIn}>
          <text x={inX} y={inY + 10}
                fontFamily={FONTS.display} fontSize="54"
                fontStyle="italic"
                fill={THEME.ink}>In</text>
        </g>
        {/* In → LLM arrow */}
        <g opacity={opArrow1}>
          <line x1={inX + 60} y1={inY} x2={llmX - 10} y2={llmCy}
                stroke={THEME.ink} strokeWidth="2.5"
                markerEnd="url(#arr-ink2)" />
        </g>

        {/* LLM box */}
        <g opacity={opLLM}>
          <text x={llmCx} y={boxY - 20}
                textAnchor="middle"
                fontFamily={FONTS.display} fontSize="48"
                fontStyle="italic"
                fill={THEME.ink}>LLM call</text>
          <rect
            x={llmX} y={boxY} width={llmW} height={boxH}
            rx="20" ry="20"
            fill={llmActive ? '#ede6d6' : 'transparent'}
            stroke={THEME.ink}
            strokeWidth="2"
            strokeDasharray="10 10"
            style={{ transition: 'fill 200ms' }}
          />
          {/* Brain emoji */}
          <text x={llmCx} y={llmCy + 40}
                textAnchor="middle"
                fontSize="120">🧠</text>
        </g>

        {/* LLM → Tool arrow with "action" label */}
        <g opacity={opArrow2}>
          <line x1={llmX + llmW} y1={llmCy} x2={toolX - 10} y2={toolCy}
                stroke={THEME.ink} strokeWidth="2.5"
                markerEnd="url(#arr-ink2)" />
        </g>
        <g opacity={opAction}>
          <text x={(llmX + llmW + toolX) / 2} y={llmCy - 30}
                textAnchor="middle"
                fontFamily={FONTS.display} fontSize="42"
                fontStyle="italic"
                fill={THEME.ink}>action</text>
        </g>

        {/* Tool box */}
        <g opacity={opTool}>
          <text x={toolCx} y={boxY - 20}
                textAnchor="middle"
                fontFamily={FONTS.display} fontSize="48"
                fontStyle="italic"
                fill={THEME.ink}>Tool</text>
          <rect
            x={toolX} y={boxY} width={toolW} height={boxH}
            rx="20" ry="20"
            fill={toolActive ? '#ede6d6' : 'transparent'}
            stroke={THEME.ink}
            strokeWidth="2"
            strokeDasharray="10 10"
            style={{ transition: 'fill 200ms' }}
          />
          {/* Hammer+wrench emoji */}
          <text x={toolCx} y={toolCy + 40}
                textAnchor="middle"
                fontSize="110">🛠️</text>
        </g>

        {/* Tool → Out arrow */}
        <g opacity={opArrow3}>
          <line x1={toolX + toolW} y1={toolCy} x2={outX - 70} y2={outY}
                stroke={THEME.ink} strokeWidth="2.5"
                markerEnd="url(#arr-ink2)" />
        </g>

        {/* Out label */}
        <g opacity={opOut}>
          <text x={outX} y={outY + 10}
                fontFamily={FONTS.display} fontSize="54"
                fontStyle="italic"
                fill={THEME.ink}>Out</text>
        </g>

        {/* Feedback arc: Tool bottom → LLM bottom, below both boxes */}
        <g opacity={opFeedback}>
          <path
            d={`M ${toolX + 60} ${boxY + boxH}
                Q ${(llmCx + toolCx) / 2} 920,
                  ${llmX + llmW - 60} ${boxY + boxH}`}
            fill="none"
            stroke={THEME.ink}
            strokeWidth="2.5"
            markerEnd="url(#arr-ink2)"
          />
          <text
            x={(llmCx + toolCx) / 2} y={970}
            textAnchor="middle"
            fontFamily={FONTS.display} fontSize="44"
            fontStyle="italic"
            fill={THEME.ink}>
            feedback
          </text>
        </g>

        {/* Traveling packet */}
        {dotOp > 0 && (
          <g>
            <circle cx={dotX} cy={dotY} r="11" fill={THEME.terra} />
            <circle cx={dotX} cy={dotY} r="22" fill={THEME.terra} opacity="0.18" />
          </g>
        )}
      </svg>

      {/* Bottom tag */}
      <div style={{
        position: 'absolute', bottom: 60, left: 80,
        fontFamily: FONTS.mono, fontSize: 16, color: THEME.muted,
        letterSpacing: '0.14em', textTransform: 'uppercase',
        display: 'flex', alignItems: 'center', gap: 18,
        ...q(2.0),
      }}>
        <span style={{ width: 28, height: 1, background: THEME.rule }}/>
        decide · call · observe · stop
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SCENE 5 — WHAT TOOLS CAN CLAUDE USE (TABLE)
// ─────────────────────────────────────────────────────────────
function SceneToolTable({ start, end }) {
  return (
    <Sprite start={start} end={end}>
      <ToolTableInner />
    </Sprite>
  );
}

function ToolTableInner() {
  const { localTime } = useSprite();
  const q = (d) => ({
    opacity: clamp((localTime - d) / 0.5, 0, 1),
    transform: `translateY(${(1 - clamp((localTime - d) / 0.5, 0, 1)) * 12}px)`,
  });

  const rows = [
    { cat: 'File ops',   desc: 'Read, edit, create, rename' },
    { cat: 'Search',     desc: 'Glob, regex, codebase exploration' },
    { cat: 'Execution',  desc: 'Shell, tests, git' },
    { cat: 'Web',        desc: 'Search, fetch docs, lookup errors' },
    { cat: 'Code intel', desc: 'Type errors, definitions, references (via plugins)' },
  ];

  return (
    <div style={{ position: 'absolute', inset: 0, background: THEME.paper, ...PAPER_GRAIN }}>
      <SceneChrome section="Tool inventory" index={5} total={18} />

      <div style={{
        position: 'absolute', top: 160, left: 80,
        fontFamily: FONTS.display, fontSize: 88,
        color: THEME.ink, letterSpacing: '-0.02em', lineHeight: 1,
        ...q(0.1),
      }}>
        What Claude can <span style={{ fontStyle: 'italic', color: THEME.terra }}>actually do.</span>
      </div>

      <div style={{
        position: 'absolute', top: 400, left: 80, right: 80,
      }}>
        {/* Header */}
        <div style={{
          display: 'grid', gridTemplateColumns: '360px 1fr',
          padding: '14px 0',
          borderBottom: `2px solid ${THEME.ink}`,
          fontFamily: FONTS.mono, fontSize: 14,
          letterSpacing: '0.16em', textTransform: 'uppercase',
          color: THEME.muted,
          ...q(0.6),
        }}>
          <div>Category</div>
          <div>What Claude can do</div>
        </div>

        {/* Rows */}
        {rows.map((r, i) => (
          <div key={i} style={{
            display: 'grid', gridTemplateColumns: '360px 1fr',
            padding: '28px 0',
            borderBottom: `1px solid ${THEME.rule}`,
            ...q(0.9 + i * 0.22),
          }}>
            <div style={{
              fontFamily: FONTS.display, fontSize: 42,
              color: THEME.ink, letterSpacing: '-0.01em',
              fontStyle: 'italic',
            }}>
              {r.cat}
            </div>
            <div style={{
              fontFamily: FONTS.body, fontSize: 24,
              color: THEME.inkSoft, lineHeight: 1.4,
              alignSelf: 'center',
            }}>
              {r.desc}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SCENE 6 — CONTEXT IS EVERYTHING
// ─────────────────────────────────────────────────────────────
function SceneContext({ start, end }) {
  return (
    <Sprite start={start} end={end}>
      <ContextInner />
    </Sprite>
  );
}

function ContextInner() {
  const { localTime } = useSprite();
  const q = (d) => ({
    opacity: clamp((localTime - d) / 0.5, 0, 1),
    transform: `translateY(${(1 - clamp((localTime - d) / 0.5, 0, 1)) * 12}px)`,
  });

  // Context window fill meter — animates from 0 to ~90% then flickers "dumber"
  const fill = interpolate([0, 2.2, 3.6, 4.2], [0, 0.5, 0.92, 0.92], Easing.easeInOutCubic)(localTime);

  return (
    <div style={{ position: 'absolute', inset: 0, background: THEME.paper, ...PAPER_GRAIN }}>
      <SceneChrome section="Context is everything" index={6} total={18} />

      <div style={{
        position: 'absolute', top: 160, left: 80,
        fontFamily: FONTS.display, fontSize: 88,
        color: THEME.ink, letterSpacing: '-0.02em', lineHeight: 1,
        ...q(0.1),
      }}>
        Context is <span style={{ fontStyle: 'italic', color: THEME.terra }}>everything.</span>
      </div>
      <div style={{
        position: 'absolute', top: 278, left: 80,
        fontFamily: FONTS.body, fontSize: 22, color: THEME.inkSoft, maxWidth: 900,
        ...q(0.5),
      }}>
        The window is finite. It fills up. And when it fills, the model gets dumber.
      </div>

      {/* Context meter — big horizontal bar */}
      <div style={{
        position: 'absolute', top: 430, left: 80, right: 80,
        ...q(0.8),
      }}>
        <div style={{
          fontFamily: FONTS.mono, fontSize: 13, color: THEME.muted,
          letterSpacing: '0.14em', textTransform: 'uppercase',
          display: 'flex', justifyContent: 'space-between',
          marginBottom: 14,
        }}>
          <span>CONTEXT WINDOW</span>
          <span style={{ fontVariantNumeric: 'tabular-nums' }}>{Math.round(fill * 100)}% FULL</span>
        </div>
        <div style={{
          height: 36,
          background: THEME.paperDeep,
          border: `1px solid ${THEME.rule}`,
          position: 'relative',
          overflow: 'hidden',
        }}>
          <div style={{
            width: `${fill * 100}%`,
            height: '100%',
            background: `linear-gradient(90deg, ${THEME.sage} 0%, ${THEME.ochre} 55%, ${THEME.terra} 100%)`,
            transition: 'width 80ms linear',
          }}/>
          {/* Tick marks */}
          {[0.25, 0.5, 0.75].map((x, i) => (
            <div key={i} style={{
              position: 'absolute',
              left: `${x * 100}%`, top: 0, bottom: 0,
              width: 1, background: THEME.paper, opacity: 0.5,
            }}/>
          ))}
        </div>
      </div>

      {/* Three context sources */}
      <div style={{
        position: 'absolute', top: 600, left: 80, right: 80,
        display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 40,
      }}>
        {[
          { tag: 'CLAUDE.md', desc: 'Always-loaded project context. `.claude/CLAUDE.md` (project) · `~/.claude/CLAUDE.md` (personal).' },
          { tag: 'Memory',    desc: 'Facts that persist across sessions.' },
          { tag: 'The rule',  desc: 'If you explain it twice, codify it. CLAUDE.md, skill, or memory.' },
        ].map((it, i) => (
          <div key={i} style={{
            ...q(2.4 + i * 0.22),
            borderTop: `2px solid ${i === 2 ? THEME.terra : THEME.ink}`,
            paddingTop: 18,
          }}>
            <div style={{
              fontFamily: FONTS.mono, fontSize: 14,
              color: i === 2 ? THEME.terra : THEME.muted,
              letterSpacing: '0.14em', textTransform: 'uppercase',
              marginBottom: 16,
            }}>
              {String(i + 1).padStart(2, '0')} · {it.tag}
            </div>
            <div style={{
              fontFamily: FONTS.body, fontSize: 20,
              color: THEME.inkSoft, lineHeight: 1.5,
            }}>
              {it.desc}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, {
  SceneTitle, SceneAgent, SceneLoop, SceneTools, SceneToolTable, SceneContext,
});
